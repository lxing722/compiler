import java.io.*;
import java.util.*;

// **********************************************************************
// The ASTnode class defines the nodes of the abstract-syntax tree that
// represents a Moo program.
//
// Internal nodes of the tree contain pointers to children, organized
// either in a list (for nodes that may have a variable number of 
// children) or as a fixed set of fields.
//
// The nodes for literals and ids contain line and character number
// information; for string literals and identifiers, they also contain a
// string; for integer literals, they also contain an integer value.
//
// Here are all the different kinds of AST nodes and what kinds of children
// they have.  All of these kinds of AST nodes are subclasses of "ASTnode".
// Indentation indicates further subclassing:
//
//     Subclass            Kids
//     --------            ----
//     ProgramNode         DeclListNode
//     DeclListNode        linked list of DeclNode
//     DeclNode:
//       VarDeclNode       TypeNode, IdNode, int
//       FnDeclNode        TypeNode, IdNode, FormalsListNode, FnBodyNode
//       FormalDeclNode    TypeNode, IdNode
//       StructDeclNode    IdNode, DeclListNode
//
//     FormalsListNode     linked list of FormalDeclNode
//     FnBodyNode          DeclListNode, StmtListNode
//     StmtListNode        linked list of StmtNode
//     ExpListNode         linked list of ExpNode
//
//     TypeNode:
//       IntNode           -- none --
//       BoolNode          -- none --
//       VoidNode          -- none --
//       StructNode        IdNode
//
//     StmtNode:
//       AssignStmtNode      AssignNode
//       PostIncStmtNode     ExpNode
//       PostDecStmtNode     ExpNode
//       ReadStmtNode        ExpNode
//       WriteStmtNode       ExpNode
//       IfStmtNode          ExpNode, DeclListNode, StmtListNode
//       IfElseStmtNode      ExpNode, DeclListNode, StmtListNode,
//                                    DeclListNode, StmtListNode
//       WhileStmtNode       ExpNode, DeclListNode, StmtListNode
//       CallStmtNode        CallExpNode
//       ReturnStmtNode      ExpNode
//
//     ExpNode:
//       IntLitNode          -- none --
//       StrLitNode          -- none --
//       TrueNode            -- none --
//       FalseNode           -- none --
//       IdNode              -- none --
//       DotAccessNode       ExpNode, IdNode
//       AssignNode          ExpNode, ExpNode
//       CallExpNode         IdNode, ExpListNode
//       UnaryExpNode        ExpNode
//         UnaryMinusNode
//         NotNode
//       BinaryExpNode       ExpNode ExpNode
//         PlusNode     
//         MinusNode
//         TimesNode
//         DivideNode
//         AndNode
//         OrNode
//         EqualsNode
//         NotEqualsNode
//         LessNode
//         GreaterNode
//         LessEqNode
//         GreaterEqNode
//
// Here are the different kinds of AST nodes again, organized according to
// whether they are leaves, internal nodes with linked lists of kids, or
// internal nodes with a fixed number of kids:
//
// (1) Leaf nodes:
//        IntNode,   BoolNode,  VoidNode,  IntLitNode,  StrLitNode,
//        TrueNode,  FalseNode, IdNode
//
// (2) Internal nodes with (possibly empty) linked lists of children:
//        DeclListNode, FormalsListNode, StmtListNode, ExpListNode
//
// (3) Internal nodes with fixed numbers of kids:
//        ProgramNode,     VarDeclNode,     FnDeclNode,     FormalDeclNode,
//        StructDeclNode,  FnBodyNode,      StructNode,     AssignStmtNode,
//        PostIncStmtNode, PostDecStmtNode, ReadStmtNode,   WriteStmtNode   
//        IfStmtNode,      IfElseStmtNode,  WhileStmtNode,  CallStmtNode
//        ReturnStmtNode,  DotAccessNode,   AssignExpNode,  CallExpNode,
//        UnaryExpNode,    BinaryExpNode,   UnaryMinusNode, NotNode,
//        PlusNode,        MinusNode,       TimesNode,      DivideNode,
//        AndNode,         OrNode,          EqualsNode,     NotEqualsNode,
//        LessNode,        GreaterNode,     LessEqNode,     GreaterEqNode
//
// **********************************************************************

// **********************************************************************
// ASTnode class (base class for all other kinds of nodes)
// **********************************************************************

abstract class ASTnode {
    
    // every subclass must provide an unparse operation
    public void unparse(PrintWriter p, int indent) {
    }

    // this method can be used by the unparse methods to do indenting
    protected void doIndent(PrintWriter p, int indent) {
        for (int k=0; k<indent; k++) p.print(" ");
    }
}

// **********************************************************************
// ProgramNode,  DeclListNode, FormalsListNode, FnBodyNode,
// StmtListNode, ExpListNode
// **********************************************************************

class ProgramNode extends ASTnode {
    // TO COMPLETE
}

class DeclListNode extends ASTnode {
    // TO COMPLETE
}

class FormalsListNode extends ASTnode {
    // TO COMPLETE
}

class FnBodyNode extends ASTnode {
    // TO COMPLETE
}

class StmtListNode extends ASTnode {
    // TO COMPLETE
}

class ExpListNode extends ASTnode {
    // TO COMPLETE
}

// **********************************************************************
// DeclNode and its subclasses
// **********************************************************************

abstract class DeclNode extends ASTnode {
}

class VarDeclNode extends DeclNode {
    // TO COMPLETE
    
    ///// DO NOT CHANGE THIS PART /////
    private int mySize;  // use value NOT_STRUCT if this is not a struct type
    public static int NOT_STRUCT = -1;
}

class FnDeclNode extends DeclNode {
    // TO COMPLETE
}

class FormalDeclNode extends DeclNode {
    // TO COMPLETE
}

class StructDeclNode extends DeclNode {
    // TO COMPLETE
}

// **********************************************************************
// TypeNode and its Subclasses
// **********************************************************************

abstract class TypeNode extends ASTnode {
}

class IntNode extends TypeNode {
    // TO COMPLETE
}

class BoolNode extends TypeNode {
    // TO COMPLETE
}

class VoidNode extends TypeNode {
    // TO COMPLETE
}

class StructNode extends TypeNode {
    // TO COMPLETE
}

// **********************************************************************
// StmtNode and its subclasses
// **********************************************************************

abstract class StmtNode extends ASTnode {
}

class AssignStmtNode extends StmtNode {
    // TO COMPLETE
}

class PostIncStmtNode extends StmtNode {
    // TO COMPLETE
}

class PostDecStmtNode extends StmtNode {
    // TO COMPLETE
}

class ReadStmtNode extends StmtNode {
    // TO COMPLETE
}

class WriteStmtNode extends StmtNode {
    // TO COMPLETE
}

class IfStmtNode extends StmtNode {
    // TO COMPLETE
}

class IfElseStmtNode extends StmtNode {
    // TO COMPLETE
}

class WhileStmtNode extends StmtNode {
    // TO COMPLETE
}

class CallStmtNode extends StmtNode {
    // TO COMPLETE
}

class ReturnStmtNode extends StmtNode {
    // TO COMPLETE
}

// **********************************************************************
// ExpNode and its subclasses
// **********************************************************************

abstract class ExpNode extends ASTnode {
}

class IntLitNode extends ExpNode {
    // TO COMPLETE
}

class StringLitNode extends ExpNode {
    // TO COMPLETE
}

class TrueNode extends ExpNode {
    // TO COMPLETE
}

class FalseNode extends ExpNode {
    // TO COMPLETE
}

class IdNode extends ExpNode {
    // TO COMPLETE
}

class DotAccessExpNode extends ExpNode {
    // TO COMPLETE
}

class AssignNode extends ExpNode {
    // TO COMPLETE
}

class CallExpNode extends ExpNode {
    // TO COMPLETE
}

abstract class UnaryExpNode extends ExpNode {
    // TO COMPLETE
}

abstract class BinaryExpNode extends ExpNode {
    // TO COMPLETE
}

// **********************************************************************
// Subclasses of UnaryExpNode
// **********************************************************************

class UnaryMinusNode extends UnaryExpNode {
    // TO COMPLETE
}

class NotNode extends UnaryExpNode {
    // TO COMPLETE
}

// **********************************************************************
// Subclasses of BinaryExpNode
// **********************************************************************

class PlusNode extends BinaryExpNode {
    // TO COMPLETE
}

class MinusNode extends BinaryExpNode {
    // TO COMPLETE
}

class TimesNode extends BinaryExpNode {
    // TO COMPLETE
}

class DivideNode extends BinaryExpNode {
    // TO COMPLETE
}

class AndNode extends BinaryExpNode {
    // TO COMPLETE
}

class OrNode extends BinaryExpNode {
    // TO COMPLETE
}

class EqualsNode extends BinaryExpNode {
    // TO COMPLETE
}

class NotEqualsNode extends BinaryExpNode {
    // TO COMPLETE
}

class LessNode extends BinaryExpNode {
    // TO COMPLETE
}

class GreaterNode extends BinaryExpNode {
    // TO COMPLETE
}

class LessEqNode extends BinaryExpNode {
    // TO COMPLETE
}

class GreaterEqNode extends BinaryExpNode {
    // TO COMPLETE
}
